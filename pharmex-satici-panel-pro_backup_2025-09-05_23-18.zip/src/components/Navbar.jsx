import { NavLink } from "react-router-dom";

const tabs = [
  { to: "/dashboard", label: "Başlangıç" },
  { to: "/products",  label: "Ürün Yönetimi" },
  { to: "/orders",    label: "Siparişler" },
  { to: "/returns",   label: "İadeler" },
  { to: "/documents", label: "Evraklar" },
  { to: "/settings",  label: "Ayarlar" },
];

export default function Navbar() {
  return (
    <div className="nav">
      <div className="nav-title">Pharmex Satıcı Paneli</div>
      <div className="nav-tabs">
        {tabs.map(t => (
          <NavLink key={t.to} to={t.to} className={({isActive}) => "tab" + (isActive?" active":"")}>
            {t.label}
          </NavLink>
        ))}
      </div>
    </div>
  );
}