import React from "react";
import { NavLink } from "react-router-dom";

const linkStyle = {
  display: "block",
  padding: "10px 14px",
  borderRadius: 8,
  color: "#e8edf5",
  textDecoration: "none",
  fontSize: 14,
};

const activeStyle = { background: "#304ffe", color: "#fff" };

export default function Sidebar() {
  return (
    <aside
      style={{
        width: 220,
        background: "#0f172a",
        color: "#cbd5e1",
        padding: 16,
        display: "flex",
        flexDirection: "column",
        gap: 8,
      }}
    >
      <div style={{ fontWeight: 700, color: "#fff", fontSize: 18, marginBottom: 12 }}>
        Pharmex Satıcı Paneli
      </div>

      <NavLink to="/dashboard" style={linkStyle} end
        className={({ isActive }) => (isActive ? "active" : "")}
      >
        Dashboard
      </NavLink>

      <NavLink to="/products" style={linkStyle}
        className={({ isActive }) => (isActive ? "active" : "")}
      >
        Ürünler
      </NavLink>

      <NavLink to="/orders" style={linkStyle}
        className={({ isActive }) => (isActive ? "active" : "")}
      >
        Siparişler
      </NavLink>

      <NavLink to="/returns" style={linkStyle}
        className={({ isActive }) => (isActive ? "active" : "")}
      >
        İadeler
      </NavLink>

      <NavLink to="/payouts" style={linkStyle}
        className={({ isActive }) => (isActive ? "active" : "")}
      >
        Hakedişler
      </NavLink>

      <style>{`
        .active { background:#304ffe !important; color:#fff !important; }
      `}</style>
    </aside>
  );
}