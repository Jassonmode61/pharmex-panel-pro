import dayjs from "dayjs";
import { load } from "../storage";
import { calcPayoutBase, round2 } from "../utils/payouts";

function slice15(orders, which){
  // which: 1 => 1-15, 2 => 16-ay sonu
  return orders.filter(o=>{
    const d = dayjs(o.date);
    const day = d.date();
    return which===1 ? day<=15 : day>15;
  });
}

export default function Payouts(){
  const st = load();
  const orders = st.orders || [];
  const kdv = Number(st?.settings?.kdvRate ?? 20);
  const kom = Number(st?.settings?.commissionRate ?? 10);

  const p1 = calcPayoutBase(slice15(orders,1), kdv, kom);
  const p2 = calcPayoutBase(slice15(orders,2), kdv, kom);

  const sumGross = round2(p1.gross + p2.gross);
  const sumComm  = round2(p1.commission + p2.commission);
  const sumVat   = round2(p1.vat + p2.vat);
  const sumNet   = round2(p1.net + p2.net);

  const month = dayjs().format("MMMM YYYY");

  const box = (title,p)=>(
    <div className="card">
      <div className="head">{title}</div>
      <div className="body">
        <div className="kv"><div className="k">Brüt Satış</div><div>₺{round2(p.gross).toFixed(2)}</div></div>
        <div className="kv"><div className="k">Komisyon Oranı</div><div>% {p.commissionRate.toFixed(2)}</div></div>
        <div className="kv"><div className="k">Komisyon</div><div>₺{round2(p.commission).toFixed(2)}</div></div>
        <div className="kv"><div className="k">KDV Oranı</div><div>% {p.kdvRate.toFixed(2)}</div></div>
        <div className="kv"><div className="k">KDV (Komisyon)</div><div>₺{round2(p.vat).toFixed(2)}</div></div>
        <hr className="sep"/>
        <div className="kv"><div className="k"><b>Ödenecek Tutar</b></div><div><b>₺{round2(p.net).toFixed(2)}</b></div></div>
      </div>
    </div>
  );

  return (
    <div className="container grid cols-2">
      {box(`1. Dönem (1–15 ${month})`, p1)}
      {box(`2. Dönem (16–${dayjs().daysInMonth()} ${month})`, p2)}

      <div className="card">
        <div className="head">Özet</div>
        <div className="body">
          <div className="kv"><div className="k">Toplam Brüt Satış</div><div>₺{sumGross.toFixed(2)}</div></div>
          <div className="kv"><div className="k">Toplam Komisyon</div><div>₺{sumComm.toFixed(2)}</div></div>
          <div className="kv"><div className="k">Toplam KDV (Komisyon)</div><div>₺{sumVat.toFixed(2)}</div></div>
          <div className="kv"><div className="k"><b>Toplam Ödeme (Satıcıya)</b></div><div><b>₺{sumNet.toFixed(2)}</b></div></div>
          <div style={{marginTop:12}} className="chips">
            <a className="btn" onclick="(function(){const t=document.getElementById('payouts-table'); if(!t){alert('Tablo yok');return;} const csv=[...t.rows].map(r=>[...r.cells].map(c=>c.innerText).join(',')).join('\n'); const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'})); a.download='hakedis.csv'; a.click(); URL.revokeObjectURL(a.href);})()">CSV İndir</a>
            <a className="btn" onclick="print()">PDF’e Yazdır</a>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="head">Fatura için Bilgi</div>
        <div className="body">
          <div className="kv"><div className="k">Unvan</div><div>Örnek Eczanesi</div></div>
          <div className="kv"><div className="k">Vergi Dairesi</div><div>Kadıköy</div></div>
          <div className="kv"><div className="k">Vergi No</div><div>1234567890</div></div>
          <div className="kv"><div className="k">Adres</div><div>Örnek Mah. Örnek Cad. No:1 İstanbul</div></div>
          <div className="kv"><div className="k">IBAN</div><div>TR00 0000 0000 0000 0000 0000 00</div></div>
          <div className="kv"><div className="k">E-posta</div><div>ornek@eczane.com</div></div>
        </div>
      </div>
    </div>
  );
}
