import React, { useState } from "react";
import Products from "./pages/Products";
import Orders from "./pages/Orders";
import Returns from "./pages/Returns";
import Documents from "./pages/Documents";
import Settings from "./pages/Settings";
import Dashboard from "./pages/Dashboard";

export default function App() {
  const [page, setPage] = useState("dashboard");

  return (
    <div>
      {/* Üst Menü */}
      <nav className="topnav">
        <button onClick={() => setPage("dashboard")}>Başlangıç</button>
        <button onClick={() => setPage("products")}>Ürün Yönetimi</button>
        <button onClick={() => setPage("orders")}>Siparişler</button>
        <button onClick={() => setPage("returns")}>İadeler</button>
        <button onClick={() => setPage("documents")}>Evraklar</button>
        <button onClick={() => setPage("settings")}>Ayarlar</button>
      </nav>

      {/* Sayfa İçeriği */}
      <main className="page">
        {page === "dashboard" && <Dashboard />}
        {page === "products" && <Products />}
        {page === "orders" && <Orders />}
        {page === "returns" && <Returns />}
        {page === "documents" && <Documents />}
        {page === "settings" && <Settings />}
      </main>
    </div>
  );
}