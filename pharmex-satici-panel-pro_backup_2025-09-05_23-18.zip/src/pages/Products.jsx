import { useEffect, useMemo, useState } from "react";
import { load, setPatch } from "../storage";

export default function Products() {
  const st = load() || {};
  const products = useMemo(() => st.products ?? [], [st]);

  const [f, setF] = useState({
    name: "",
    price: "",
    stock: "",
    category: "Dermatoloji",
    coldChain: false,
  });

  // İlk girişte örnek ürünleri tohumla (yalnızca ürün listesi boşsa)
  useEffect(() => {
    if (!products.length) {
      const seed = [
        { name: "Parol 500 mg",  price: 51,  stock: 3,  category: "Ağrı Kesici",  coldChain: false },
        { name: "Augmentin 625", price: 171, stock: 4,  category: "Antibiyotik", coldChain: false },
        { name: "Vitamin C",     price: 164, stock: 6,  category: "Vitamin",     coldChain: false },
        { name: "Bepanthol Krem",price: 199, stock: 12, category: "Dermatoloji", coldChain: false },
        { name: "Soğuk Zincir Aşı",price: 420,stock: 2, category: "Diğer",       coldChain: true  },
        { name: "Majezik 100 mg",price: 145, stock: 9,  category: "Ağrı Kesici",  coldChain: false },
      ].map(p => ({ id: crypto.randomUUID(), createdAt: new Date().toISOString(), ...p }));
      setPatch({ ...st, products: seed });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const fmtTL = (v) =>
    new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY" }).format(Number(v || 0));

  function addProduct(e) {
    e.preventDefault();
    if (!f.name || !f.price || !f.stock) {
      alert("Lütfen ürün adı, fiyat ve stok alanlarını doldurun.");
      return;
    }
    const nextProducts = [
      ...(products || []),
      {
        id: crypto.randomUUID(),
        name: f.name.trim(),
        price: Number(f.price),
        stock: Number(f.stock),
        category: f.category,
        coldChain: !!f.coldChain,
        createdAt: new Date().toISOString(),
      },
    ];
    setPatch({ ...st, products: nextProducts });
    setF({ name: "", price: "", stock: "", category: "Dermatoloji", coldChain: false });
  }

  return (
    <div className="container">
      {/* Bu stil bloğu sadece bu sayfayı değil, form ve tabloyu güzelleştirir */}
      <style>{`
        /* Başlıklar her temada görünür */
        h1, h2, h3, .page-title, .card .head { color:#eaf2ff; }

        /* Form düzeni */
        .product-card { margin-bottom: 18px; }
        .product-card .head { font-weight:700; font-size:18px; }
        .product-form { margin-top: 10px; }
        .product-form .row {
          display:grid; grid-template-columns: 1fr 1fr; gap:16px;
        }
        .product-form .row + .row { margin-top:14px; }
        .product-form label{
          display:block; margin-bottom:6px; font-weight:600; color:#cfe2ff;
        }
        .product-form input,.product-form select{
          width:100%; padding:10px 12px; border-radius:8px;
          border:1px solid rgba(148,163,184,.35);
          background: rgba(2,6,23,.35); color:#e5e7eb; outline:none;
        }
        .product-form input:focus,.product-form select:focus{
          border-color:#60a5fa; box-shadow:0 0 0 3px rgba(96,165,250,.15);
        }
        .product-form .actions{ display:flex; justify-content:flex-end; margin-top:12px; }

        /* Tablo – başlıklar kontrastlı */
        .product-table{ width:100%; border-collapse:collapse; }
        .product-table thead th{
          background:#1e293b; color:#f1f5f9;
          text-align:left; font-weight:700;
        }
        .product-table th,.product-table td{ padding:10px 12px; border-bottom:1px solid rgba(148,163,184,.15); }
        .table-wrap{ overflow:auto; }
      `}</style>

      <div className="card product-card">
        <div className="head">Yeni Ürün Ekle</div>
        <div className="body">
          <form className="product-form" onSubmit={addProduct}>
            <div className="row">
              <div>
                <label>Ürün Adı</label>
                <input
                  placeholder="Örn: Parol 500 mg"
                  value={f.name}
                  onChange={(e) => setF({ ...f, name: e.target.value })}
                />
              </div>
              <div>
                <label>Fiyat</label>
                <input
                  type="number" min="0" step="0.01" placeholder="Örn: 49.90"
                  value={f.price}
                  onChange={(e) => setF({ ...f, price: e.target.value })}
                />
              </div>
            </div>

            <div className="row">
              <div>
                <label>Stok</label>
                <input
                  type="number" min="0" step="1" placeholder="Örn: 25"
                  value={f.stock}
                  onChange={(e) => setF({ ...f, stock: e.target.value })}
                />
              </div>
              <div>
                <label>Kategori</label>
                <select
                  value={f.category}
                  onChange={(e) => setF({ ...f, category: e.target.value })}
                >
                  <option>Dermatoloji</option>
                  <option>Ağrı Kesici</option>
                  <option>Antibiyotik</option>
                  <option>Vitamin</option>
                  <option>Diğer</option>
                </select>
              </div>
            </div>

            <div className="row" style={{ gridTemplateColumns: "1fr" }}>
              <div className="switch">
                <input
                  id="coldChain"
                  type="checkbox"
                  checked={f.coldChain}
                  onChange={(e) => setF({ ...f, coldChain: e.target.checked })}
                />
                <label htmlFor="coldChain" style={{ marginLeft: 8 }}>Soğuk Zincir</label>
              </div>
            </div>

            <div className="actions">
              <button className="btn primary" type="submit">Ekle</button>
            </div>
          </form>
        </div>
      </div>

      <div className="card">
        <div className="head">Ürünler</div>
        <div className="body">
          {products.length === 0 ? (
            <div style={{ padding: "14px 0", opacity: .75 }}>Henüz ürün yok.</div>
          ) : (
            <div className="table-wrap">
              <table className="product-table">
                <thead>
                  <tr>
                    <th>Ad</th>
                    <th>Fiyat</th>
                    <th>Stok</th>
                    <th>Kategori</th>
                    <th>Soğuk Zincir</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map(p => (
                    <tr key={p.id}>
                      <td>{p.name}</td>
                      <td>{fmtTL(p.price)}</td>
                      <td>{p.stock}</td>
                      <td>{p.category}</td>
                      <td>{p.coldChain ? "Evet" : "Hayır"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}