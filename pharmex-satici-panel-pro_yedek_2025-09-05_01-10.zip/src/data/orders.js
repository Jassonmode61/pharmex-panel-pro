// Videodaki tabloya benzer örnekler
export const orders = [
  { id: 1, date: "2025-08-02", product: "Parol 500 mg", qty: 2, price: 259.80, status: "Teslim edildi", invoiced: "Evet" },
  { id: 2, date: "2025-08-05", product: "Augmentin 625", qty: 1, price: 349.00, status: "Hazırlanıyor", invoiced: "Hayır" },
  { id: 3, date: "2025-08-07", product: "Reçeteli Ürün (Foto yüklenmiş)", qty: 1, price: 100.00, status: "Beklemede", invoiced: "-" },
  // 7–8 adet daha
  { id: 4, date: "2025-08-09", product: "D Vitamini 1000 IU", qty: 3, price: 210.00, status: "Teslim edildi", invoiced: "Evet" },
  { id: 5, date: "2025-08-12", product: "Ağrı Kesici", qty: 1, price: 89.90, status: "İptal edildi", invoiced: "-" },
  { id: 6, date: "2025-08-13", product: "Dermatolojik Krem", qty: 2, price: 420.00, status: "Kargoda", invoiced: "Evet" },
  { id: 7, date: "2025-08-16", product: "Burun Spreyi", qty: 1, price: 129.90, status: "Hazırlanıyor", invoiced: "Hayır" },
  { id: 8, date: "2025-08-18", product: "Propolis Damla", qty: 1, price: 179.90, status: "Beklemede", invoiced: "-" },
  { id: 9, date: "2025-08-22", product: "Bebek Maması", qty: 1, price: 315.00, status: "Teslim edildi", invoiced: "Evet" },
  { id: 10, date: "2025-08-28", product: "Vitamin C", qty: 2, price: 198.00, status: "Teslim edildi", invoiced: "Evet" },
];

// Dashboard grafiği için ay bazında ciro
export function revenueByMonth(list = orders){
  const map = new Map();
  list.forEach(o=>{
    const month = new Date(o.date+"T00:00:00").getMonth(); // 0-11
    const val = (map.get(month)||0) + (o.price||0);
    map.set(month, val);
  });
  // Ocak-Haziran arası örnek (videoda 6 ay görünüyordu)
  return Array.from({length:6}, (_,i)=> ({ m:i, value: +(map.get(i)||0).toFixed(2) }));
}