import { useMemo, useState } from "react";
import { load } from "../storage";
import "./orders-returns.css";

export default function Orders() {
  const st = load() || {};
  const [orders] = useState(
    Array.isArray(st.orders) && st.orders.length ? st.orders : seedOrders()
  );

  // sayfalama
  const [page, setPage] = useState(1);
  const pageSize = 15;
  const totalPages = Math.max(1, Math.ceil(orders.length / pageSize));
  const list = useMemo(
    () => orders.slice((page - 1) * pageSize, page * pageSize),
    [orders, page]
  );

  // detay popup
  const [selected, setSelected] = useState(null);
  const closeDetail = () => setSelected(null);

  const fmtTRY = (n) =>
    new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY" }).format(n);

  function printOrder(o) {
    const w = window.open("", "_blank", "width=850,height=1000");
    if (!w || w.closed) {
      alert("Açılır pencere engellendi. Lütfen bu site için açılır pencerelere izin verin.");
      return;
    }

    const badgeHTML = (() => {
      if (o.status === "delivered")
        return '<span class="badge green">Teslim edildi</span>';
      if (o.status === "preparing")
        return '<span class="badge warning">Hazırlanıyor</span>';
      return '<span class="badge gray">Beklemede</span>';
    })();

    const html = `<!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8"/>
<title>Sipariş Yazdır</title>
<style>
  *{box-sizing:border-box;font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Inter,Arial,sans-serif}
  body{padding:24px}
  h1{font-size:20px;margin:0 0 12px}
  .row{display:flex;gap:16px;margin:4px 0}
  .label{width:140px;opacity:.7}
  table{width:100%;border-collapse:collapse;margin-top:12px}
  th,td{border:1px solid #ddd;padding:8px;text-align:left}
  .tot{font-weight:600}
  .badge{display:inline-block;padding:4px 10px;border-radius:999px;font-size:12px;border:1px solid #ccc}
  .green{background:#e8f6ee;border-color:#4caf50;color:#256f34}
  .warning{background:#fff5e6;border-color:#f5a623;color:#7a4b00}
  .gray{background:#eef1f5;border-color:#cbd5e1;color:#334155}
  @media print { @page { size: A4; margin: 12mm } }
</style>
</head>
<body>
  <h1>Pharmex Satıcı Paneli — Sipariş Özeti</h1>
  <div class="row"><div class="label">Tarih</div><div>${o.date}</div></div>
  <div class="row"><div class="label">Müşteri</div><div>${o.customer}</div></div>
  <div class="row"><div class="label">Durum</div><div>${badgeHTML}</div></div>
  <div class="row"><div class="label">Muadil</div><div>${o.substitute ? "Evet" : "Hayır"}</div></div>
  <table>
    <thead><tr><th>Ürün</th><th>Adet</th><th>Tutar</th></tr></thead>
    <tbody>
      <tr><td>${o.product}</td><td>${o.qty}</td><td>${fmtTRY(o.amount)}</td></tr>
      <tr><td class="tot" colspan="2">Toplam</td><td class="tot">${fmtTRY(o.amount)}</td></tr>
    </tbody>
  </table>
  <script>window.onload=()=>window.print()</script>
</body>
</html>`;

    w.document.open();
    w.document.write(html);
    w.document.close();
  }

  return (
    <div className="container">
      <h2>Siparişler</h2>
      <div className="card">
        <div className="body">
          <table className="table">
            <thead>
              <tr>
                <th>Tarih</th>
                <th>Müşteri</th>
                <th>Ürün</th>
                <th style={{width:80}}>Adet</th>
                <th style={{width:140}}>Tutar</th>
                <th style={{width:130}}>Durum</th>
                <th style={{width:110}}>Muadil</th>
                <th style={{width:160, textAlign:"right"}}>İşlem</th>
              </tr>
            </thead>
            <tbody>
              {list.map(o => (
                <tr key={o.id}>
                  <td>{o.date}</td>
                  <td>{o.customer}</td>
                  <td>{o.product}</td>
                  <td>{o.qty}</td>
                  <td>{fmtTRY(o.amount)}</td>
                  <td>
                    {o.status === "delivered" && <span className="badge green">Teslim edildi</span>}
                    {o.status === "preparing" && <span className="badge warning">Hazırlanıyor</span>}
                    {o.status === "pending" && <span className="badge gray">Beklemede</span>}
                  </td>
                  <td>{o.substitute ? "Muadil: Evet" : "Muadil: Hayır"}</td>
                  <td style={{textAlign:"right"}}>
                    <button className="btn" onClick={()=>setSelected(o)}>Detay</button>
                    <button className="btn primary" style={{marginLeft:8}} onClick={()=>printOrder(o)}>Yazdır</button>
                  </td>
                </tr>
              ))}
              {!list.length && (
                <tr><td colSpan={8} style={{textAlign:"center",opacity:.6}}>Kayıt yok.</td></tr>
              )}
            </tbody>
          </table>

          <div className="pager">
            {Array.from({length: totalPages}, (_,i)=>i+1).map(p=>(
              <button key={p} className={"btn"+(p===page?" primary":"")} onClick={()=>setPage(p)}>{p}</button>
            ))}
          </div>
        </div>
      </div>

      {selected && (
        <>
          <div className="modal-backdrop" onClick={()=>setSelected(null)} />
          <div className="modal">
            <div className="modal-head" style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div className="title">Sipariş Detayı — #{selected.id}</div>
              <button className="btn" onClick={()=>setSelected(null)}>Kapat</button>
            </div>
            <div className="modal-body" style={{marginTop:10}}>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                <Info label="Tarih" value={selected.date}/>
                <Info label="Müşteri" value={selected.customer}/>
                <Info label="Durum" value={{
                  delivered:"Teslim edildi", preparing:"Hazırlanıyor", pending:"Beklemede"
                }[selected.status]}/>
                <Info label="Muadil" value={selected.substitute ? "Evet" : "Hayır"}/>
              </div>
              <table className="table" style={{marginTop:12}}>
                <thead><tr><th>Ürün</th><th style={{width:80}}>Adet</th><th style={{width:140}}>Tutar</th></tr></thead>
                <tbody>
                  <tr><td>{selected.product}</td><td>{selected.qty}</td><td>{fmtTRY(selected.amount)}</td></tr>
                  <tr><td colSpan={2} style={{textAlign:"right",fontWeight:600}}>Toplam</td><td style={{fontWeight:600}}>{fmtTRY(selected.amount)}</td></tr>
                </tbody>
              </table>
              <div className="toolbar" style={{marginTop:12}}>
                <button className="btn" onClick={()=>setSelected(null)}>Kapat</button>
                <button className="btn primary" style={{marginLeft:8}} onClick={()=>printOrder(selected)}>Yazdır</button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function Info({label, value}) {
  return (
    <div style={{display:"flex",gap:8}}>
      <div style={{width:120,opacity:.7}}>{label}</div>
      <div>{value}</div>
    </div>
  );
}

function seedOrders(){
  const arr=[];
  for(let i=1;i<=40;i++){
    arr.push({
      id:i,
      date:`2025-08-${String((i%28)+1).padStart(2,"0")}`,
      customer:["Mavi Eczane","Ada Eczanesi","Öncü Eczane"][i%3],
      product:["Parol 500 mg","Augmentin 625","Vitamin C"][i%3],
      qty:(i%4)+1,
      amount:150+i*7,
      status:["delivered","preparing","pending"][i%3],
      substitute:i%2===0
    });
  }
  return arr;
}