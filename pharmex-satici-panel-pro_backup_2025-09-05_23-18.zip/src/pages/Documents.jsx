import { useState } from "react";
import { load, setPatch } from "../storage";

const KVKK_TEXT = `KVKK Aydınlatma Metni burada yer alacak. Kullanıcı verilerinin korunması hakkında bilgilendirme...`;
const CONTRACT_TEXT = `Satıcı Sözleşmesi burada yer alacak. Tarafların hak ve yükümlülüklerini düzenler...`;

export default function Documents(){
  const st = load() || {};
  const initial = {
    kvkk: st.docs?.kvkk || { read:false, approved:false, locked:false },
    contract: st.docs?.contract || { read:false, approved:false, locked:false },
    uploads: st.docs?.uploads || { tax:null, license:null, room:null, sign:null }
  };
  const [docs,setDocs] = useState(initial);
  const [openText,setOpenText] = useState(null);

  function setDoc(key,next){
    const n={...docs,[key]:{...docs[key],...next}};
    setDocs(n); setPatch({docs:n});
  }

  return (
    <div className="container">
      <h2>Evraklar</h2>

      <div className="card">
        <div className="head">Evrak Onayları</div>
        <div className="body">
          <ApprovalRow title="KVKK Aydınlatma Metni" state={docs.kvkk}
            onRead={()=>{setDoc("kvkk",{read:true});setOpenText("kvkk")}}
            onApprove={()=>setDoc("kvkk",{approved:true,locked:true})}/>
          <ApprovalRow title="Satıcı Sözleşmesi" state={docs.contract}
            onRead={()=>{setDoc("contract",{read:true});setOpenText("contract")}}
            onApprove={()=>setDoc("contract",{approved:true,locked:true})}/>
        </div>
      </div>

      <div className="card" style={{marginTop:12}}>
        <div className="head">Belge Yüklemeleri</div>
        <div className="body" style={{display:"grid",gap:"12px"}}>
          <UploadRow label="Vergi Levhası" name="tax" docs={docs} setDoc={setDoc}/>
          <UploadRow label="Eczacı/İşletme Ruhsatı" name="license" docs={docs} setDoc={setDoc}/>
          <UploadRow label="Oda Kayıt Belgesi" name="room" docs={docs} setDoc={setDoc}/>
          <UploadRow label="İmza Sirküleri" name="sign" docs={docs} setDoc={setDoc}/>
        </div>
      </div>

      {openText && (
        <>
          <div className="modal-backdrop" onClick={()=>setOpenText(null)} />
          <div className="modal">
            <div className="modal-head">
              <div className="title">{openText==="kvkk"?"KVKK Aydınlatma Metni":"Satıcı Sözleşmesi"}</div>
              <button className="btn" onClick={()=>setOpenText(null)}>Kapat</button>
            </div>
            <div className="modal-body" style={{maxHeight:"60vh",overflowY:"auto",whiteSpace:"pre-line"}}>
              {openText==="kvkk"?KVKK_TEXT:CONTRACT_TEXT}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function ApprovalRow({title,state,onRead,onApprove}){
  return (
    <div style={{marginBottom:12}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div>{title}</div>
        <div>
          <button className="btn" onClick={onRead} disabled={state.locked}>Oku</button>
          <button className="btn primary" style={{marginLeft:8}} onClick={onApprove} disabled={!state.read||state.locked}>Onayla</button>
        </div>
      </div>
      <div style={{marginTop:6}}>
        {state.approved?<span className="badge green">Onaylandı</span>:
         state.read?<span className="badge warning">Okundu, onay bekliyor</span>:
         <span className="badge gray">Okunmadı</span>}
      </div>
    </div>
  );
}

function UploadRow({label,name,docs,setDoc}){
  const file=docs.uploads[name];
  function onPick(e){
    const f=e.target.files?.[0]; if(!f) return;
    const reader=new FileReader();
    reader.onload=()=>{
      const n={...docs.uploads,[name]:{name:f.name,data:reader.result}};
      setDoc("uploads",n);
    };
    reader.readAsDataURL(f);
  }
  return (
    <div style={{display:"flex",alignItems:"center",gap:"12px"}}>
      <div style={{flex:"0 0 220px"}}>{label}</div>
      <label className="btn"><input type="file" style={{display:"none"}} onChange={onPick}/>Dosya Seç</label>
      <div style={{opacity:.7}}>{file?file.name:"seçili dosya yok"}</div>
    </div>
  );
}