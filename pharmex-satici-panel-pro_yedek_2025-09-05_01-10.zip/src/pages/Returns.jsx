import { useMemo, useState } from "react";
import { load, setPatch } from "../storage";
import "./orders-returns.css";

export default function Returns() {
  const st = load() || {};
  const [items, setItems] = useState(
    Array.isArray(st.returns) && st.returns.length ? st.returns : seedReturns()
  );

  // sayfalama
  const [page, setPage] = useState(1);
  const pageSize = 15;
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  const list = useMemo(()=>items.slice((page-1)*pageSize, page*pageSize), [items,page]);

  // detay popup
  const [selected, setSelected] = useState(null);

  const fmtTRY = (n) =>
    new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY" }).format(n);

  function decide(row, decision){
    if(row.locked) return;
    const next = items.map(x => x.id===row.id ? { ...x, decision, locked:true } : x);
    setItems(next);
    setPatch({ returns: next });
  }

  return (
    <div className="container">
      <h2>İade Talepleri</h2>
      <div className="card">
        <div className="body">
          <table className="table">
            <thead>
              <tr>
                <th>Tarih</th>
                <th>Ürün</th>
                <th>Gerekçe</th>
                <th style={{width:140}}>Tutar</th>
                <th style={{width:260}}>İşlem</th>
              </tr>
            </thead>
            <tbody>
              {list.map(r=>(
                <tr key={r.id}>
                  <td>{r.date}</td>
                  <td>{r.product}</td>
                  <td>{r.reason}</td>
                  <td>{fmtTRY(r.amount)}</td>
                  <td>
                    <div style={{display:"flex",gap:8}}>
                      <button className="btn" onClick={()=>setSelected(r)}>Detay</button>
                      <button
                        className={"btn"+(r.decision==="approved" ? " primary": "")}
                        style={{
                          background: r.decision==="approved" ? "#e8f6ee" : "",
                          borderColor: r.decision==="approved" ? "#4caf50" : "",
                          color: r.decision==="approved" ? "#256f34" : ""
                        }}
                        disabled={r.locked}
                        onClick={()=>decide(r,"approved")}
                      >Onayla</button>
                      <button
                        className="btn"
                        style={{
                          background: r.decision==="rejected" ? "#fdeaea" : "",
                          borderColor: r.decision==="rejected" ? "#ef4444" : "",
                          color: r.decision==="rejected" ? "#7f1d1d" : ""
                        }}
                        disabled={r.locked}
                        onClick={()=>decide(r,"rejected")}
                      >Reddet</button>
                    </div>
                  </td>
                </tr>
              ))}
              {!list.length && (
                <tr><td colSpan={5} style={{textAlign:"center",opacity:.6}}>Kayıt yok.</td></tr>
              )}
            </tbody>
          </table>

          <div className="pager">
            {Array.from({length: totalPages}, (_,i)=>i+1).map(p=>(
              <button key={p} className={"btn"+(p===page?" primary":"")} onClick={()=>setPage(p)}>{p}</button>
            ))}
          </div>
        </div>
      </div>

      {selected && (
        <>
          <div className="modal-backdrop" onClick={()=>setSelected(null)} />
          <div className="modal">
            <div className="modal-head" style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div className="title">İade Detayı — #{selected.id}</div>
              <button className="btn" onClick={()=>setSelected(null)}>Kapat</button>
            </div>
            <div className="modal-body" style={{marginTop:10}}>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
                <Info label="Tarih" value={selected.date}/>
                <Info label="Ürün" value={selected.product}/>
                <Info label="Tutar" value={fmtTRY(selected.amount)}/>
                <Info label="Durum" value={
                  selected.decision==="approved" ? "Onaylı" :
                  selected.decision==="rejected" ? "Reddedildi" : "Beklemede"
                }/>
              </div>
              <div style={{marginTop:12}}>
                <div style={{opacity:.7,marginBottom:4}}>İade Nedeni</div>
                <div style={{padding:10,border:"1px solid #e5e7eb",borderRadius:8,background:"#fafafa"}}>
                  {selected.reason}
                </div>
              </div>
              <div className="toolbar" style={{marginTop:12}}>
                <button className="btn" onClick={()=>setSelected(null)}>Kapat</button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function Info({label, value}) {
  return (
    <div style={{display:"flex",gap:8}}>
      <div style={{width:140,opacity:.7}}>{label}</div>
      <div>{value}</div>
    </div>
  );
}

function seedReturns(){
  const arr=[]; const reasons=[
    "Son kullanma tarihi geçmiş",
    "Yanlış ürün gönderildi",
    "Ambalaj hasarı",
    "Kullanıcı vazgeçti"
  ];
  for(let i=1;i<=32;i++){
    arr.push({
      id:i,
      date:`2025-08-${String((i%28)+1).padStart(2,"0")}`,
      product:["Ağrı Kesici","Bebek Maması","Vitamin C"][i%3],
      reason:reasons[i%reasons.length],
      amount:100+i*5,
      decision:null, // "approved" | "rejected"
      locked:false
    });
  }
  return arr;
}