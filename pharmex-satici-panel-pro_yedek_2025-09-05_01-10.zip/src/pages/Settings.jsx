import { load, setPatch } from "../storage";
import { useState } from "react";

export default function Settings(){
  const st = load();
  const [f,setF] = useState({
    name: st?.infoLocked ? st?.info?.name : "",
    phone: st?.infoLocked ? st?.info?.phone : "",
    address: st?.infoLocked ? st?.info?.address : "",
    openHour: st?.settings?.openHour ?? 9,
    closeHour: st?.settings?.closeHour ?? 18,
    vacation: !!st?.settings?.vacation,
    duty: !!st?.settings?.duty,
    kdvRate: st?.kdvRate ?? 20,
    commissionRate: st?.commissionRate ?? 10
  });

  function save(){
    const next = {
      ...st,
      settings:{
        openHour:Number(f.openHour),
        closeHour:Number(f.closeHour),
        vacation:f.vacation,
        duty:f.duty
      },
      kdvRate:Number(f.kdvRate),
      commissionRate:Number(f.commissionRate)
    };
    if(!st.infoLocked){
      next.infoLocked = true;
      next.info = { name:f.name, phone:f.phone, address:f.address };
    }
    setPatch(next);
    alert("Kaydedildi");
    location.reload();
  }

  return (
    <div className="grid" style={{gap:16}}>
      <h2>Ayarlar</h2>

      <div className="grid cards">
        <div className="card">
          <h4>Eczane Bilgileri</h4>
          <div className="grid" style={{gridTemplateColumns:"1fr 1fr", gap:12}}>
            <div>
              <label>Ad</label>
              <input className="input" disabled={!!st.infoLocked}
                     value={f.name} onChange={e=>setF({...f,name:e.target.value})}/>
            </div>
            <div>
              <label>Telefon</label>
              <input className="input" disabled={!!st.infoLocked}
                     value={f.phone} onChange={e=>setF({...f,phone:e.target.value})}/>
            </div>
            <div style={{gridColumn:"1/-1"}}>
              <label>Adres</label>
              <textarea className="input" rows={3} disabled={!!st.infoLocked}
                        value={f.address} onChange={e=>setF({...f,address:e.target.value})}/>
            </div>
          </div>
          {st.infoLocked && (
            <div className="small" style={{marginTop:8}}>
              Bu alanları bir kere değiştirebilirsiniz. Sonrasında değişiklik için yönetici ile iletişime geçin.
            </div>
          )}
        </div>

        <div className="card">
          <h4>Çalışma Ayarları</h4>
          <div className="grid" style={{gridTemplateColumns:"1fr 1fr", gap:12}}>
            <div>
              <label>Açılış</label>
              <input className="input" type="number"
                     value={f.openHour} onChange={e=>setF({...f,openHour:e.target.value})}/>
            </div>
            <div>
              <label>Kapanış</label>
              <input className="input" type="number"
                     value={f.closeHour} onChange={e=>setF({...f,closeHour:e.target.value})}/>
            </div>
          </div>

          <div className="flex" style={{gap:12, marginTop:10}}>
            <label className="flex" style={{gap:6, alignItems:"center"}}>
              <input type="checkbox" checked={f.vacation}
                     onChange={e=>setF({...f,vacation:e.target.checked})}/>
              Tatil modu
            </label>
            <label className="flex" style={{gap:6, alignItems:"center"}}>
              <input type="checkbox" checked={f.duty}
                     onChange={e=>setF({...f,duty:e.target.checked})}/>
              Nöbetçi (18:00 sonrası açık)
            </label>
          </div>

          <div className="hr"/>

          <div className="grid" style={{gridTemplateColumns:"1fr 1fr", gap:12}}>
            <div>
              <label>KDV Oranı (%)</label>
              <input className="input" type="number"
                     value={f.kdvRate} onChange={e=>setF({...f,kdvRate:e.target.value})}/>
            </div>
            <div>
              <label>Komisyon Oranı (%)</label>
              <input className="input" type="number"
                     value={f.commissionRate} onChange={e=>setF({...f,commissionRate:e.target.value})}/>
            </div>
          </div>

          <div className="flex" style={{justifyContent:"end", marginTop:12}}>
            <button className="btn" onClick={save}>Kaydet</button>
          </div>
        </div>
      </div>
    </div>
  );
}