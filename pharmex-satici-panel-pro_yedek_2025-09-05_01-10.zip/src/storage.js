// Basit localStorage yardımcıları
const KEY = "phx:seller";

export function load() {
  try { return JSON.parse(localStorage.getItem(KEY)) || {}; }
  catch { return {}; }
}

export function setPatch(next) {
  // next'i doğrudan kaydediyoruz (Settings.jsx zaten birleşik nesne gönderiyor)
  localStorage.setItem(KEY, JSON.stringify(next || {}));
}