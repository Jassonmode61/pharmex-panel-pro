import { useMemo, useState } from "react";
import { load, setPatch } from "../storage";

export default function Returns() {
  const st = load();
  const [selected, setSelected] = useState(null);
  const [page, setPage] = useState(1);
  const pageSize = 15;

  const rows = useMemo(() => {
    const base = st?.returns?.length ? st.returns : sampleReturns;
    return base;
  }, [st]);

  const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
  const pageRows = rows.slice((page - 1) * pageSize, page * pageSize);

  function setDecision(idx, decision) {
    const next = rows.map((r, i) =>
      i === idx ? { ...r, decision, locked: true } : r
    );
    setPatch({ ...st, returns: next });
  }

  return (
    <div className="returns-page">
      {/* sayfaya özel stiller (yalnızca .returns-page altında işler) */}
      <style>{`
        .returns-page { padding: 24px; }
        .returns-page .page-title{ font-weight:700; margin:0 0 16px; }
        .returns-page .table-wrap{ background:#0f1a2b; border:1px solid #24324d; border-radius:12px; overflow:hidden }
        .returns-page table{ width:100%; border-collapse:collapse; font-size:14.5px }
        .returns-page thead th{ background:#0a1630; color:#d7e3fb; text-align:left; padding:12px; border-bottom:1px solid #24324d }
        .returns-page tbody td{ color:#e8eef7; padding:12px; border-bottom:1px solid #24324d }
        .returns-page tbody tr:hover{ background:rgba(255,255,255,.03) }

        .returns-page .btn{ background:#0f3f85; color:#fff; border:1px solid #214f90; padding:6px 12px; border-radius:8px; cursor:pointer }
        .returns-page .btn.ghost{ background:transparent; border-color:#2b3b5e }
        .returns-page .btn.success{ background:#22c55e; border-color:#1f8c59 }
        .returns-page .btn.danger{ background:#ef4444; border-color:#a42d2d }
        .returns-page .btn:disabled{ opacity:.5; cursor:not-allowed }

        /* Modal */
        .returns-page .modal-overlay{ position:fixed; inset:0; background:rgba(0,0,0,.45); display:flex; align-items:center; justify-content:center; z-index:1000 }
        .returns-page .modal-card{ width:min(720px,92vw); background:#0f1a2b; color:#e8eef7; border:1px solid #24324d; border-radius:12px; box-shadow:0 12px 40px rgba(0,0,0,.5); overflow:hidden }
        .returns-page .modal-head{ display:flex; align-items:center; justify-content:space-between; padding:14px 16px; border-bottom:1px solid #24324d; font-weight:600 }
        .returns-page .modal-body{ padding:16px }
        .returns-page .modal-actions{ display:flex; justify-content:flex-end; gap:8px; padding:12px 16px; border-top:1px solid #24324d }

        .returns-page .form-grid{ display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:14px }
        .returns-page .form-grid > div{ display:flex; flex-direction:column; gap:6px }
        .returns-page label{ color:#aeb8cc; font-size:13px }
        .returns-page input, .returns-page textarea{
          background:#111c31; color:#e8eef7; border:1px solid #24324d; border-radius:10px; padding:10px 12px; outline:none
        }
        .returns-page textarea{ min-height:40px; resize:vertical }

        /* sayfalama */
        .returns-page .pager{ display:flex; gap:8px; justify-content:center; margin-top:16px }
      `}</style>

      <h1 className="page-title">İade Talepleri</h1>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th style={{ width: 140 }}>Tarih</th>
              <th>Ürün</th>
              <th>Gerekçe</th>
              <th style={{ width: 120 }}>Tutar</th>
              <th style={{ width: 180 }}>İşlem</th>
            </tr>
          </thead>
          <tbody>
            {pageRows.map((r, i) => {
              const idx = (page - 1) * pageSize + i;
              return (
                <tr key={idx}>
                  <td>{r.date}</td>
                  <td>{r.product}</td>
                  <td>{r.reason}</td>
                  <td>{formatTRY(r.amount)}</td>
                  <td>
                    <div style={{ display: "flex", gap: 8 }}>
                      <button
                        className="btn ghost"
                        onClick={() => setSelected({ ...r, no: idx + 1 })}
                      >
                        Detay
                      </button>
                      <button
                        className={`btn ${
                          r.decision === "approve" ? "success" : "ghost"
                        }`}
                        disabled={r.locked}
                        onClick={() => setDecision(idx, "approve")}
                        title={r.locked ? "Karar verilmiş" : "Onayla"}
                      >
                        Onayla
                      </button>
                      <button
                        className={`btn ${
                          r.decision === "reject" ? "danger" : "ghost"
                        }`}
                        disabled={r.locked}
                        onClick={() => setDecision(idx, "reject")}
                        title={r.locked ? "Karar verilmiş" : "Reddet"}
                      >
                        Reddet
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {pageRows.length === 0 && (
              <tr>
                <td colSpan={5} style={{ textAlign: "center", padding: 22 }}>
                  Kayıt yok.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Sayfalama */}
      {totalPages > 1 && (
        <div className="pager">
          <button
            className="btn ghost"
            disabled={page === 1}
            onClick={() => setPage(page - 1)}
          >
            Önceki
          </button>
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
            <button
              key={p}
              className={`btn ${p === page ? "" : "ghost"}`}
              onClick={() => setPage(p)}
            >
              {p}
            </button>
          ))}
          <button
            className="btn ghost"
            disabled={page === totalPages}
            onClick={() => setPage(page + 1)}
          >
            Sonraki
          </button>
        </div>
      )}

      {/* Detay Modal */}
      {selected && (
        <div className="modal-overlay" onClick={() => setSelected(null)}>
          <div className="modal-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-head">
              <div>İade Detayı — #{selected.no}</div>
              <button className="btn ghost" onClick={() => setSelected(null)}>
                Kapat
              </button>
            </div>
            <div className="modal-body">
              <div className="form-grid">
                <div>
                  <label>Tarih</label>
                  <input value={selected.date} readOnly />
                </div>
                <div>
                  <label>Ürün</label>
                  <input value={selected.product} readOnly />
                </div>
                <div>
                  <label>Tutar</label>
                  <input value={formatTRY(selected.amount)} readOnly />
                </div>
                <div>
                  <label>Durum</label>
                  <input
                    value={
                      selected.decision === "approve"
                        ? "Onaylı"
                        : selected.decision === "reject"
                        ? "Reddedildi"
                        : "Beklemede"
                    }
                    readOnly
                  />
                </div>
                <div style={{ gridColumn: "1/-1" }}>
                  <label>İade Nedeni</label>
                  <textarea value={selected.reason} readOnly />
                </div>
              </div>
            </div>
            <div className="modal-actions">
              <button className="btn ghost" onClick={() => setSelected(null)}>
                Kapat
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

/* Yardımcılar */
function formatTRY(n) {
  try {
    return new Intl.NumberFormat("tr-TR", {
      style: "currency",
      currency: "TRY",
    }).format(n);
  } catch {
    return `${n} ₺`;
  }
}

/* Örnek veri, depoda yoksa */
const sampleReturns = [
  { date: "2025-08-02", product: "Bebek Maması", reason: "Yanlış ürün gönderildi", amount: 105, decision: null, locked: false },
  { date: "2025-08-03", product: "Vitamin C", reason: "Ambalaj hasarı", amount: 110, decision: "approve", locked: true },
  { date: "2025-08-04", product: "Ağrı Kesici", reason: "Kullanıcı vazgeçti", amount: 115, decision: null, locked: false },
  { date: "2025-08-05", product: "Bebek Maması", reason: "Son kullanma tarihi geçmiş", amount: 120, decision: null, locked: false },
  { date: "2025-08-06", product: "Vitamin C", reason: "Yanlış ürün gönderildi", amount: 125, decision: "reject", locked: true },
];