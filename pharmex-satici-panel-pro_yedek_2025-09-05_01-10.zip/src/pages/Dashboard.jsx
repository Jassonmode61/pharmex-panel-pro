import { orders, revenueByMonth } from "../data/orders";

function LineChart({ data }) {
  // basit SVG çizgisi
  const max = Math.max(1, ...data.map(d=>d.value));
  const pts = data.map((d,i)=> {
    const x = (i/(data.length-1))*100;
    const y = 100 - (d.value/max)*100;
    return `${x},${y}`;
  }).join(" ");
  return (
    <svg viewBox="0 0 100 100" style={{width:"100%",height:140,background:"#0f1726",border:"1px solid #1b2a44",borderRadius:8}}>
      <polyline fill="none" stroke="#63b3ff" strokeWidth="2" points={pts}/>
    </svg>
  );
}

function Donut() {
  // 4 kategoriye örnek dağılım (statik görsel)
  const segs = [
    { c:"#63b3ff", v:40, label:"Antibiyotik" },
    { c:"#90ee90", v:25, label:"Ağrı Kesici" },
    { c:"#ffd37a", v:20, label:"Dermatoloji" },
    { c:"#ff9aa2", v:15, label:"Diğer" },
  ];
  const total = segs.reduce((a,b)=>a+b.v,0);
  let acc = 0;
  return (
    <div className="flex" style={{gap:16,alignItems:"center"}}>
      <svg viewBox="0 0 36 36" width="140" height="140">
        <circle cx="18" cy="18" r="15.5" fill="transparent" stroke="#1b2a44" strokeWidth="3"/>
        {segs.map((s,i)=>{
          const dash = (s.v/total)*100;
          const circ = 2*Math.PI*15.5;
          const offset = circ * (1 - acc/100);
          acc += dash;
          return (
            <circle key={i} cx="18" cy="18" r="15.5"
              fill="transparent" stroke={s.c} strokeWidth="3"
              strokeDasharray={`${circ * (s.v/total)} ${circ}`}
              strokeDashoffset={offset}
            />
          );
        })}
        <circle cx="18" cy="18" r="9" fill="#0b1220"/>
      </svg>
      <div className="small">
        {segs.map(s=>(
          <div key={s.label} className="flex"><span style={{width:10,height:10,background:s.c,display:"inline-block",borderRadius:2,marginRight:6}}/> {s.label}</div>
        ))}
      </div>
    </div>
  );
}

export default function Dashboard(){
  const totalOrders = orders.length;
  const totalRevenue = orders.reduce((a,b)=>a+(b.price||0),0).toFixed(2);
  const series = revenueByMonth(orders);

  return (
    <div className="grid" style={{gap:20}}>
      <h2>Satıcı Paneli Dashboard</h2>
      <div className="grid cards">
        <div className="card">
          <h4>Toplam Sipariş</h4>
          <div className="big">{totalOrders}</div>
        </div>
        <div className="card">
          <h4>Toplam Ciro</h4>
          <div className="big">₺{totalRevenue}</div>
        </div>
      </div>

      <div className="grid cards">
        <div className="card">
          <h4>Aylık Sipariş & Ciro</h4>
          <LineChart data={series}/>
          <div className="small" style={{opacity:.8,marginTop:6}}>Ocak – Haziran</div>
        </div>

        <div className="card">
          <h4>Kategori Dağılımı</h4>
          <Donut/>
        </div>
      </div>
    </div>
  );
}